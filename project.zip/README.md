# Mancala (Kalah 6x4)

A full-stack Mancala game: **.NET 8 API** backend + **Angular 18** frontend,
same structure as the Snakes & Ladders project.

## Rules implemented (in the API, `GameService.cs`)
- 6 pits per side, 4 seeds per pit, one store per player (48 seeds total)
- Sow counter-clockwise, skipping the opponent's store
- Last seed in your store = extra turn
- Last seed in an empty pit on your side = capture that seed + all opposite seeds
- Game ends when one side is empty; the other player collects the remaining seeds
- Play vs a friend (2 players) or vs the Computer (1-ply look-ahead AI in the API)

## API
| Method | Route | Body / notes |
|---|---|---|
| GET | `/api/rules` | Variant info |
| POST | `/api/games` | `{ "playerNames": ["A","B"], "vsComputer": false }` |
| GET | `/api/games/{id}` | Current state |
| POST | `/api/games/{id}/move` | `{ "pit": 0 }` — pit 0-5 = Player 1, 7-12 = Player 2 |
| POST | `/api/games/{id}/computer-move` | Computer (Player 2) takes one move |
| POST | `/api/games/{id}/join` | Online: claim a seat — 1st joiner = Player 1, 2nd = Player 2, then spectator |

## Online multiplayer (real-time, one game ID)
- Transport: **SignalR** hub at `/hubs/mancala`. Clients invoke `JoinGame(gameId)`
  to join the group named by the game ID; after every move the API broadcasts
  `GameUpdated` with the full state to the group — no polling, no refresh.
- Flow: Player 1 creates a game in Online mode and shares the game ID or the
  invite link (`?game=<id>`). Player 2 opens it in another browser and joins.
  Each browser is locked to its own pits: moves carry the player index and the
  API rejects out-of-turn or other-side moves (400).
- Games are held in server memory, so both players must be connected to the
  same running API instance, and a game lasts while that server stays up.

Board is a 14-slot array: Player 1 pits 0-5, Player 1 store 6,
Player 2 pits 7-12, Player 2 store 13.

## Run it
Backend (serves the API on http://localhost:5000):
```
cd backend/Mancala.Api
dotnet run
```
Frontend dev server (proxies /api to the backend):
```
cd frontend
npm install
npm start        # http://localhost:4200
```

## Single deployable (like Snakes & Ladders)
Build the Angular app and copy it into the API's `wwwroot`, then `dotnet run`
serves both the game page and the API from one process:
```
cd frontend && npm run build
cp -r dist/mancala-frontend/browser/* ../backend/Mancala.Api/wwwroot/
cd ../backend/Mancala.Api && dotnet run
```
