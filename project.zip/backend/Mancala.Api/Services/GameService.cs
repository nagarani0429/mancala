using Mancala.Api.Models;

namespace Mancala.Api.Services;

/// Mancala (Kalah 6x4) rules:
/// - Pick up all seeds from one of your pits and sow one per slot counter-clockwise,
///   including your own store, skipping your opponent's store.
/// - Last seed in your store = one extra turn.
/// - Last seed in an empty pit on your side, with seeds opposite = capture both
///   into your store.
/// - The game ends when either side's six pits are all empty; the other player
///   collects their remaining seeds into their store. Most seeds in store wins.
public class GameService
{
    private readonly Dictionary<Guid, GameState> _games = new();
    private readonly object _lock = new();

    public static int StoreOf(int player) => player == 0 ? 6 : 13;
    public static int PitStart(int player) => player == 0 ? 0 : 7;
    public static bool IsOwnPit(int player, int pit) =>
        pit >= PitStart(player) && pit < PitStart(player) + 6;

    public GameState CreateGame(string[]? names, bool vsComputer = false)
    {
        var clean = (names ?? Array.Empty<string>())
            .Select(n => string.IsNullOrWhiteSpace(n) ? null : n.Trim())
            .ToArray();
        var game = new GameState
        {
            Id = Guid.NewGuid(),
            PlayerNames = new[]
            {
                clean.ElementAtOrDefault(0) ?? "Player 1",
                vsComputer ? "Computer" : (clean.ElementAtOrDefault(1) ?? "Player 2")
            },
            VsComputer = vsComputer,
            Message = ""
        };
        for (int i = 0; i < 14; i++)
            game.Board[i] = (i == 6 || i == 13) ? 0 : 4;
        game.Message = $"{game.PlayerNames[0]} to move.";
        lock (_lock) _games[game.Id] = game;
        return game;
    }

    public GameState? GetGame(Guid id)
    {
        lock (_lock) return _games.TryGetValue(id, out var g) ? g : null;
    }

    public GameState MakeMove(Guid id, int pit, int? player = null)
    {
        lock (_lock)
        {
            if (!_games.TryGetValue(id, out var g))
                throw new KeyNotFoundException("Game not found.");
            if (player is not null && player != g.CurrentPlayer)
                throw new InvalidOperationException("It is not your turn.");
            if (player is not null && !IsOwnPit(player.Value, pit))
                throw new InvalidOperationException("You can only play your own pits.");
            ApplyMove(g, pit);
            return g;
        }
    }

    /// Online multiplayer: claim a seat in an existing game.
    /// First joiner plays as Player 1 (index 0), second as Player 2 (index 1),
    /// anyone after that joins as a spectator.
    public JoinResult JoinGame(Guid id)
    {
        lock (_lock)
        {
            if (!_games.TryGetValue(id, out var g))
                throw new KeyNotFoundException("Game not found.");
            int seat = g.PlayersJoined;
            if (seat < 2) g.PlayersJoined++;
            return new JoinResult(id, Math.Min(seat, 1), seat >= 2);
        }
    }

    /// Picks and plays the computer's move (player 2). One ply look-ahead:
    /// scores each legal pit by store gain, capture size and extra turns,
    /// simulating the move on a clone.
    public GameState MakeComputerMove(Guid id)
    {
        lock (_lock)
        {
            if (!_games.TryGetValue(id, out var g))
                throw new KeyNotFoundException("Game not found.");
            if (g.IsGameOver) return g;
            if (g.CurrentPlayer != 1)
                throw new InvalidOperationException("It is not the computer's turn.");

            int bestPit = -1, bestScore = int.MinValue;
            for (int pit = 7; pit <= 12; pit++)
            {
                if (g.Board[pit] == 0) continue;
                var clone = Clone(g);
                int storeBefore = clone.Board[13];
                ApplyMove(clone, pit, quiet: true);
                int score = (clone.Board[13] - storeBefore) * 10
                          + clone.LastMoveCaptured * 2
                          + (clone.LastMoveExtraTurn ? 6 : 0)
                          + (clone.IsGameOver && clone.Winner == 1 ? 100 : 0);
                // Prefer moves that do not hand the opponent a big capture:
                // count seeds left landing on the opponent side is handled implicitly.
                if (score > bestScore) { bestScore = score; bestPit = pit; }
            }
            if (bestPit < 0) throw new InvalidOperationException("No legal move.");
            ApplyMove(g, bestPit);
            return g;
        }
    }

    private static GameState Clone(GameState g) => new()
    {
        Id = g.Id, Board = (int[])g.Board.Clone(), PlayerNames = g.PlayerNames,
        VsComputer = g.VsComputer, CurrentPlayer = g.CurrentPlayer,
        IsGameOver = g.IsGameOver, Winner = g.Winner, IsDraw = g.IsDraw,
        Message = g.Message, MoveCount = g.MoveCount
    };

    private static void ApplyMove(GameState g, int pit, bool quiet = false)
    {
        if (g.IsGameOver) throw new InvalidOperationException("The game is over.");
        int player = g.CurrentPlayer;
        if (!IsOwnPit(player, pit))
            throw new InvalidOperationException("Choose one of your own pits.");
        if (g.Board[pit] == 0)
            throw new InvalidOperationException("That pit is empty.");

        int ownStore = StoreOf(player), oppStore = StoreOf(1 - player);
        int seeds = g.Board[pit];
        g.Board[pit] = 0;
        int idx = pit;
        while (seeds > 0)
        {
            idx = (idx + 1) % 14;
            if (idx == oppStore) continue; // skip opponent's store
            g.Board[idx]++;
            seeds--;
        }

        bool extraTurn = idx == ownStore;
        int captured = 0;
        // Capture: last seed in an empty own pit (board==1 means it was empty before)
        if (!extraTurn && IsOwnPit(player, idx) && g.Board[idx] == 1)
        {
            int opposite = 12 - idx;
            if (g.Board[opposite] > 0)
            {
                captured = g.Board[opposite] + 1;
                g.Board[ownStore] += captured;
                g.Board[opposite] = 0;
                g.Board[idx] = 0;
            }
        }

        g.LastPit = pit;
        g.LastMoveExtraTurn = extraTurn;
        g.LastMoveCaptured = captured;
        g.MoveCount++;

        // Game end: either side empty
        int side0 = Enumerable.Range(0, 6).Sum(i => g.Board[i]);
        int side1 = Enumerable.Range(7, 6).Sum(i => g.Board[i]);
        if (side0 == 0 || side1 == 0)
        {
            g.Board[6] += side0;
            g.Board[13] += side1;
            for (int i = 0; i < 6; i++) { g.Board[i] = 0; g.Board[7 + i] = 0; }
            g.IsGameOver = true;
            g.Winner = g.Board[6] == g.Board[13] ? null : (g.Board[6] > g.Board[13] ? 0 : 1);
            g.IsDraw = g.Board[6] == g.Board[13];
            if (!quiet)
                g.Message = g.IsDraw
                    ? $"It's a draw, {g.Board[6]}-{g.Board[13]}!"
                    : $"{g.PlayerNames[g.Winner!.Value]} wins {Math.Max(g.Board[6], g.Board[13])}-{Math.Min(g.Board[6], g.Board[13])}!";
            return;
        }

        if (!extraTurn) g.CurrentPlayer = 1 - player;
        if (!quiet)
        {
            var who = g.PlayerNames[g.CurrentPlayer];
            g.Message = captured > 0
                ? $"Captured {captured} seeds! {who} to move."
                : extraTurn ? $"Last seed in the store - {who} goes again!"
                : $"{who} to move.";
        }
    }
}
