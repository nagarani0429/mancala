namespace Mancala.Api.Models;

/// Board layout (14 slots):
///   Player 2 pits: 7..12   Player 2 store: 13
///   Player 1 pits: 0..5    Player 1 store: 6
/// Sowing goes counter-clockwise: index + 1, wrapping 13 -> 0,
/// skipping the opponent's store.
public class GameState
{
    public Guid Id { get; set; }
    public int[] Board { get; set; } = new int[14];
    public string[] PlayerNames { get; set; } = new[] { "Player 1", "Player 2" };
    public bool VsComputer { get; set; }
    public int CurrentPlayer { get; set; } // 0 or 1
    public bool IsGameOver { get; set; }
    public int? Winner { get; set; }      // 0, 1, or null while playing / on a draw see IsDraw
    public bool IsDraw { get; set; }
    public string Message { get; set; } = "";
    public int MoveCount { get; set; }
    public int? LastPit { get; set; }     // pit chosen in the last move
    public bool LastMoveExtraTurn { get; set; }
    public int LastMoveCaptured { get; set; }
    public int PlayersJoined { get; set; } // online mode: 0,1,2 (further joiners spectate)
}

public record CreateGameRequest(string[]? PlayerNames, bool VsComputer = false);
public record MoveRequest(int Pit, int? Player = null);
public record JoinResult(Guid GameId, int Player, bool IsSpectator);
