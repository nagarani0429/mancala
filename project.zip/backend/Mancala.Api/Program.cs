using Mancala.Api.Hubs;
using Mancala.Api.Models;
using Mancala.Api.Services;
using Microsoft.AspNetCore.SignalR;

var builder = WebApplication.CreateBuilder(args);

// Hosts like Render set PORT; bind to it when present.
var port = Environment.GetEnvironmentVariable("PORT");
if (!string.IsNullOrEmpty(port)) builder.WebHost.UseUrls($"http://+:{port}");

builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));
builder.Services.AddSingleton<GameService>();
builder.Services.AddSignalR();

var app = builder.Build();
app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapHub<MancalaHub>("/hubs/mancala");

static async Task Broadcast(IHubContext<MancalaHub> hub, GameState game) =>
    await hub.Clients.Group(game.Id.ToString()).SendAsync("GameUpdated", game);

app.MapGet("/api/rules", () => Results.Ok(new
{
    variant = "Kalah 6x4",
    pitsPerSide = 6,
    seedsPerPit = 4,
    extraTurnOnStore = true,
    captureOnEmptyOwnPit = true,
    realtime = "SignalR hub at /hubs/mancala, event GameUpdated, group = game ID"
}));

app.MapPost("/api/games", (CreateGameRequest req, GameService svc) =>
    Results.Created("/api/games", svc.CreateGame(req.PlayerNames, req.VsComputer)));

app.MapGet("/api/games/{id:guid}", (Guid id, GameService svc) =>
    svc.GetGame(id) is { } game ? Results.Ok(game) : Results.NotFound());

// Online multiplayer: claim a seat (Player 1, Player 2, then spectator).
app.MapPost("/api/games/{id:guid}/join", (Guid id, GameService svc) =>
{
    try { return Results.Ok(svc.JoinGame(id)); }
    catch (KeyNotFoundException) { return Results.NotFound(); }
});

app.MapPost("/api/games/{id:guid}/move", async (Guid id, MoveRequest req, GameService svc, IHubContext<MancalaHub> hub) =>
{
    try
    {
        var game = svc.MakeMove(id, req.Pit, req.Player);
        await Broadcast(hub, game);
        return Results.Ok(game);
    }
    catch (KeyNotFoundException) { return Results.NotFound(); }
    catch (InvalidOperationException ex) { return Results.BadRequest(new { error = ex.Message }); }
});

app.MapPost("/api/games/{id:guid}/computer-move", async (Guid id, GameService svc, IHubContext<MancalaHub> hub) =>
{
    try
    {
        var game = svc.MakeComputerMove(id);
        await Broadcast(hub, game);
        return Results.Ok(game);
    }
    catch (KeyNotFoundException) { return Results.NotFound(); }
    catch (InvalidOperationException ex) { return Results.BadRequest(new { error = ex.Message }); }
});

app.MapFallbackToFile("index.html");
app.Run();
