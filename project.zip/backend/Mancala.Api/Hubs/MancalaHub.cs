using Microsoft.AspNetCore.SignalR;

namespace Mancala.Api.Hubs;

/// Real-time channel for online games. Clients join the group named by the
/// game ID; after every move the API broadcasts "GameUpdated" with the full
/// game state to everyone in that group, so both browsers stay in sync
/// instantly with no polling or refresh.
public class MancalaHub : Hub
{
    public Task JoinGame(string gameId) =>
        Groups.AddToGroupAsync(Context.ConnectionId, gameId);

    public Task LeaveGame(string gameId) =>
        Groups.RemoveFromGroupAsync(Context.ConnectionId, gameId);
}
