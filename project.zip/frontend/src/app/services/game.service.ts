import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import * as signalR from '@microsoft/signalr';
import { environment } from '../../environments/environment';
import { GameState, JoinResult } from '../models/game.models';

@Injectable({ providedIn: 'root' })
export class GameService {
  private base = environment.apiUrl;
  private hub: signalR.HubConnection | null = null;
  readonly gameUpdated$ = new Subject<GameState>();

  constructor(private http: HttpClient) {}

  createGame(playerNames: string[], vsComputer: boolean): Observable<GameState> {
    return this.http.post<GameState>(`${this.base}/api/games`, { playerNames, vsComputer });
  }
  getGame(id: string): Observable<GameState> {
    return this.http.get<GameState>(`${this.base}/api/games/${id}`);
  }
  joinGame(id: string): Observable<JoinResult> {
    return this.http.post<JoinResult>(`${this.base}/api/games/${id}/join`, {});
  }
  makeMove(id: string, pit: number, player?: number): Observable<GameState> {
    return this.http.post<GameState>(`${this.base}/api/games/${id}/move`, { pit, player });
  }
  computerMove(id: string): Observable<GameState> {
    return this.http.post<GameState>(`${this.base}/api/games/${id}/computer-move`, {});
  }

  /** Connect to the SignalR hub and join this game's group.
      Every move by either player is pushed back as GameUpdated. */
  async connectToGame(id: string): Promise<void> {
    await this.disconnect();
    this.hub = new signalR.HubConnectionBuilder()
      .withUrl(`${this.base}/hubs/mancala`)
      .withAutomaticReconnect()
      .build();
    this.hub.on('GameUpdated', (g: GameState) => this.gameUpdated$.next(g));
    await this.hub.start();
    await this.hub.invoke('JoinGame', id);
  }
  async disconnect(): Promise<void> {
    if (this.hub) { try { await this.hub.stop(); } catch {} this.hub = null; }
  }
}
