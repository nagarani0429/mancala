export interface GameState {
  id: string;
  board: number[];
  playerNames: string[];
  vsComputer: boolean;
  currentPlayer: number;
  isGameOver: boolean;
  winner: number | null;
  isDraw: boolean;
  message: string;
  moveCount: number;
  lastPit: number | null;
  lastMoveExtraTurn: boolean;
  lastMoveCaptured: number;
  playersJoined: number;
}
export interface JoinResult { gameId: string; player: number; isSpectator: boolean; }
