import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { GameService } from '../../services/game.service';
import { GameState } from '../../models/game.models';

type Mode = 'local' | 'computer' | 'online';

@Component({
  selector: 'app-board',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './board.component.html',
  styleUrl: './board.component.css'
})
export class BoardComponent implements OnInit, OnDestroy {
  game: GameState | null = null;
  name1 = 'Player 1';
  name2 = 'Player 2';
  mode: Mode = 'local';
  joinId = '';
  myPlayer: number | null = null;   // online seat: 0 or 1, null = spectator/local
  spectator = false;
  busy = false;
  error = '';
  copied = false;
  private sub?: Subscription;

  topPits = [12, 11, 10, 9, 8, 7];
  bottomPits = [0, 1, 2, 3, 4, 5];

  constructor(private svc: GameService) {}

  ngOnInit(): void {
    this.sub = this.svc.gameUpdated$.subscribe(g => { this.game = g; });
    const q = new URLSearchParams(window.location.search).get('game');
    if (q) { this.mode = 'online'; this.joinId = q; }
  }
  ngOnDestroy(): void { this.sub?.unsubscribe(); this.svc.disconnect(); }

  get shareLink(): string {
    return this.game ? `${window.location.origin}${window.location.pathname}?game=${this.game.id}` : '';
  }

  start(): void {
    this.error = ''; this.copied = false;
    if (this.mode === 'online') { this.startOnline(); return; }
    this.svc.createGame([this.name1.trim() || 'Player 1', this.name2.trim() || 'Player 2'], this.mode === 'computer')
      .subscribe({ next: g => this.game = g, error: () => this.error = 'Could not reach the API. Is the .NET backend running?' });
  }

  private startOnline(): void {
    this.svc.createGame([this.name1.trim() || 'Player 1', 'Player 2'], false).subscribe({
      next: g => {
        this.game = g;
        this.svc.joinGame(g.id).subscribe({
          next: async j => { this.myPlayer = j.player; this.spectator = j.isSpectator; await this.svc.connectToGame(g.id); },
          error: () => this.error = 'Could not join the game.'
        });
      },
      error: () => this.error = 'Could not reach the API. Is the .NET backend running?'
    });
  }

  joinOnline(): void {
    const id = this.joinId.trim();
    if (!id) { this.error = 'Paste a game ID first.'; return; }
    this.error = '';
    this.svc.getGame(id).subscribe({
      next: g => {
        this.game = g;
        this.svc.joinGame(id).subscribe({
          next: async j => {
            this.myPlayer = j.player; this.spectator = j.isSpectator;
            if (!j.isSpectator && j.player === 1 && this.name2.trim())
              this.game!.playerNames[1] = this.name2.trim();
            await this.svc.connectToGame(id);
          },
          error: () => this.error = 'Could not join that game.'
        });
      },
      error: () => this.error = 'Game not found. Check the ID - games live on the server only while it is running.'
    });
  }

  copyLink(): void {
    navigator.clipboard?.writeText(this.shareLink).then(() => this.copied = true);
  }

  seeds(n: number): number[] { return Array.from({ length: n }, (_, i) => i); }

  canPlay(pit: number): boolean {
    if (!this.game || this.game.isGameOver || this.busy) return false;
    if (this.game.board[pit] === 0) return false;
    const p = this.game.currentPlayer;
    if (this.mode === 'online') {
      if (this.spectator || this.myPlayer === null || p !== this.myPlayer) return false;
    }
    return p === 0 ? (pit >= 0 && pit <= 5) : (pit >= 7 && pit <= 12);
  }

  play(pit: number): void {
    if (!this.game || !this.canPlay(pit)) return;
    this.busy = true; this.error = '';
    const player = this.mode === 'online' ? (this.myPlayer ?? undefined) : undefined;
    this.svc.makeMove(this.game.id, pit, player).subscribe({
      next: g => { this.game = g; this.busy = false; this.maybeComputer(); },
      error: e => { this.busy = false; this.error = e?.error?.error ?? 'Move failed.'; }
    });
  }

  private maybeComputer(): void {
    if (!this.game || this.mode !== 'computer' || this.game.isGameOver || this.game.currentPlayer !== 1) return;
    this.busy = true;
    setTimeout(() => {
      if (!this.game) { this.busy = false; return; }
      this.svc.computerMove(this.game.id).subscribe({
        next: g => { this.game = g; this.busy = false; this.maybeComputer(); },
        error: () => { this.busy = false; }
      });
    }, 650);
  }

  restart(): void { this.game = null; this.myPlayer = null; this.spectator = false; this.svc.disconnect(); }
}
