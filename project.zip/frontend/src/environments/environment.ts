// Empty = same origin (when .NET serves the Angular build from wwwroot).
export const environment = { production: false, apiUrl: '' };
